/* Update the placeholder contact and social details before publishing. */
window.restaurantConfig = {
  name: "Sip & Slice",
  tagline: "Good food. Better moments.",
  address: "Lodhan Chowk, Goalpokher, West Bengal, India",
  phone: "[PHONE]",
  whatsapp: "[WHATSAPP]", // International format, digits only, e.g. 919876543210
  email: "[EMAIL]",
  instagram: "[INSTAGRAM_URL]",
  facebook: "[FACEBOOK_URL]",
  youtube: "[YOUTUBE_URL]",
  googleMaps: "https://maps.google.com/?q=Lodhan+Chowk+Goalpokher+West+Bengal",
  openingHours: {
    monday: "11:00 AM - 10:30 PM", tuesday: "11:00 AM - 10:30 PM",
    wednesday: "11:00 AM - 10:30 PM", thursday: "11:00 AM - 10:30 PM",
    friday: "11:00 AM - 10:30 PM", saturday: "11:00 AM - 10:30 PM",
    sunday: "11:00 AM - 10:30 PM"
  }
};
window.assets = {
  hero: "https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=1200&q=85",
  logo: ""
};
